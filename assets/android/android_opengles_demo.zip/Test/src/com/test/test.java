/*
* file:    test.java
* author:  Shingwa Six
* website: http://www.waaile.com/
* date:    2011-08-15
*/

package com.test;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.pm.ConfigurationInfo;
import android.os.Bundle;
import android.util.Log;

public class test extends Activity {
	private static final String LOG_TAG = test.class.getSimpleName();
    private VortexView _vortexView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        _vortexView = new VortexView(this,getGLVersion());
        setContentView(_vortexView);
        Log.i(LOG_TAG,"Activity has create!");
    }
    
    /**
     * ��ȡ�豸֧�ֵ�OpenGLES�汾��
     * @return
     * ����һ������,��16λָ�����汾��,��16λָ����С�汾��.
     */
    public int getGLVersion() {
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        ConfigurationInfo info = am.getDeviceConfigurationInfo();
        return info.reqGlEsVersion;
    }
}

